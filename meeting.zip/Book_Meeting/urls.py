# from django.urls import path
# from . import views
# app_name='Booking'

# urlpatterns = [
#     path('/meeting', views.book_view, name="book_view"),
# ]