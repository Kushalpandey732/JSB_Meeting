from django.apps import AppConfig


class BookMeetingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Book_Meeting'
